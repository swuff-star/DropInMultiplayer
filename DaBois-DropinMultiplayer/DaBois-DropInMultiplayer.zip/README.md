# DropinMultiplayer
The drop in multiplayer mod for Risk of Rain 2, now updated for the Hidden Realms update!
This mod allows the host to have players join mid-game, and automatically gives them items to help them catch up!
It comes with configuration too! Don't want people to spawn in with Resonance Discs? Turn GiveRedItems off!
Only the host needs it too! If you have UnmoddedClients installed, you can let unmodded people join mid-game with no issues!
If you have any bug reports, I suggest you join the discord ( https://discord.gg/MfQtGYj ), or make an issue on the github.

### Special Thanks
* [IDeathHD](https://thunderstore.io/package/xiaoxiao921/), for fixing the issue with clipping into the floor & changing some stuff internally to work better with dedicated servers.


### Commands Examples
  1. ctrl+alt+tilde = opens console
  2. join_as Commando = Spawns you in as commando.
  3. join_as Lemurian = Spawns you in as a lemurian.	
  4. player_list = Gets the current amount of players and ids.
  5. join_as Huntress Morris1927 = Spawns Morris1927 in as Huntress, replace Morris1927 with whoever you'd like to turn into huntress/whatever in the names list .
  6. join_as MULT 0 = Spawns the player with the id ``0`` as MULT, you can replace MULT with anything in the names list.

# Installation
 1. Extract "DropInMultiplayer.dll" from the zip file and place it into  "/Risk of Rain 2/BepInEx/plugins/" folder.
 2. Done
 
### 3.1.2---
* Fixed readme

### 3.1.1---
 * Removed boss items config option, never worked
 
### 3.1.0---
 * Added new config options, you can now turn the welcome message off and dsi.
 * Changed ``dim_spawn_as`` to ``join_as``. 
 * Merged IDeathHD's fork of the mod, the weird no clipping issue should be fixed and the mod should work better on dedicated servers.
 
### 3.0.1---
* Apparently using ``dim_spawn_as Loader`` and ``dim_spawn_as Acrid`` didn't work, fixed that
* Changed the text in the welcome message. 
* Fixed the readme, was vague and confusing.


### 3.0.0---
* Added new monsters and survivors, you can now spawn as them using ``dim_spawn_as``!
* Became the maintainer of the mod, thanks Morris!
* Added two new config options, ``GiveLunarItems`` and ``GiveRedItems``.

### 2.2.1---
* Rex added to list of survivors (Thanks Violet Chaolan, sorry it took so long)
* spawn_as changed to dim_spawn_as so it doesn't conflict with RoR2Cheats

### 2.2.0---
* spawn_as is no longer case-sensitive
* Added verbose messages to command inputs
* Added aliases. eg. you can type MULT or MUL-T instead of Toolbot, or Artificer instead of Mage

### 2.1.0---
* Added more config options
* By default, players will now not be automatically put into the game (config)
* Config to enable/disable only spawning as survivors
* Config to enable/disable whether spawn_as can be used while alive

### 2.0.2---
* Added config options
* Possibly(?) fixed a bug causing players to spawn with items they shouldn't have

### 2.0.1---
* Updated to work with newest build
* Changed spawnas to spawn_as

### 2.0.0---
* Ported to BepInEx
* Added in spawnas as a chat command
* Removed the need to add Body to the end of everything

### 1.1.0---
* Fixed games not starting
* Added ability to change other peoples character (Helps if someone else doesn't have the mod)
